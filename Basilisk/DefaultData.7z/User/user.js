user_pref("browser.cache.disk.parent_directory", "User");
user_pref("browser.download.lastDir", "Downloads");
user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.taskbar.lists.enabled", false);
